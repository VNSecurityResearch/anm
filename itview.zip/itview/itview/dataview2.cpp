/* dataview2.cpp --

   This file is part of the "PE Maker".

   Copyright (C) 2005-2006 Ashkbiz Danehkar
   All Rights Reserved.

   "PE Maker" library are free software; you can redistribute them
   and/or modify them under the terms of the GNU General Public License as
   published by the Free Software Foundation.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; see the file COPYRIGHT.TXT.
   If not, write to the Free Software Foundation, Inc.,
   59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

   Ashkbiz Danehkar
   <ashkbiz@yahoo.com>
*/
#include "stdafx.h"
#include <windowsx.h>
#include <commctrl.h>
#include <stdio.h>
#include "dataview2.h"
#include "main.h"

DATAVIEW2		*szDataView2;
int				iDataView2;
HWND		hDataView2;
static DWORD	dwStyle;
static DWORD	dwExtendedStyle;

static int iCount;

//bFileOpen
BOOL DataView2_OnInitDialog(HWND hwnd, HWND hwndFocus, LPARAM lParam);
void DataView2_OnCommand (HWND hwnd, int id, HWND hwndCtl, UINT codeNotify);
void DataView2_Insert(DWORD ThunkRVA,
					DWORD ThunkOffset,
					DWORD ThunkValue,
					DWORD Hint,
					PCHAR ApiName);
void DataView2_ClearList();

#define C_COLUMNS 5
// InitListViewColumns - adds columns to a list-view
// control. 
// Returns TRUE if successful, or FALSE otherwise. 
// hWndListView - handle to the list-view control. 
static int iWidth[C_COLUMNS ]={90,90,90,75,255};
BOOL DataView2_InitListViewColumns(HWND hWndListView) 
{ 
    char szText[256];     // temporary buffer 
    LVCOLUMN lvc; 
    int iCol; 
	// Initialize the LVCOLUMN structure.
	// The mask specifies that the format, width, text, and
	// subitem members of the structure are valid. 
	lvc.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM; 	  
	// Add the columns. 
	for (iCol = 0; iCol < C_COLUMNS; iCol++) 
	{
		lvc.iSubItem = iCol;
		lvc.pszText = szText;
		lvc.cx = iWidth[iCol];     // width of column in pixels
		lvc.fmt = LVCFMT_LEFT;  // left-aligned column
		LoadString(hInst, IDS_D2_FIRSTCOLUMN + iCol, 
			szText, sizeof(szText)/sizeof(szText[0]));
		if (ListView_InsertColumn(hWndListView, iCol,&lvc) == -1) 
			return FALSE; 
	}
	return TRUE; 
} 

// This code snippet adds three items, each with three
// subitems, to a list-view control. 
// hWndListView - handle to the list-view control.
// The following application-specific structure, 
// PETINFO, is used in the snippet.

//static DATAVIEW DataView;

BOOL DataView2_OnInitDialog(HWND hwnd, HWND hwndFocus, LPARAM lParam)
{
	//SECINFO SectionInfo;
	hDataView2=GetDlgItem(hwnd,IDC_PROCNAMES);
	dwStyle = GetWindowLong(hDataView2, GWL_STYLE);
	dwStyle|= LVS_REPORT | LVS_SINGLESEL;
	dwStyle&=~LVS_NOSCROLL;
	SetWindowLong(hDataView2, GWL_STYLE, dwStyle);
	DataView2_InitListViewColumns(hDataView2);
	return FALSE;
}

void DataView2_Insert(DWORD ThunkRVA,
					DWORD ThunkOffset,
					DWORD ThunkValue,
					DWORD Hint,
					PCHAR ApiName, 
					DWORD Ordinal)
{
	CHAR stemp[127];
	LVITEM lvI;
	// Some code to create the list-view control.
	// Initialize LVITEM members that are common to all
	// items. 
	lvI.mask =  LVIF_TEXT | LVIF_STATE ; 
	lvI.state = 0; 
	lvI.stateMask = 0; 
	// Initialize LVITEM members that are different for each item. 
	lvI.iItem = iCount;
	lvI.iSubItem = 0;
	sprintf(stemp, "%08X", ThunkRVA);
	lvI.pszText = (LPSTR)stemp;
	if(ListView_InsertItem(hDataView2, &lvI) == -1) return;
	//ListView_SetItemText(hDataView1,i,1,szDataView1[i].szOffset);
	sprintf(stemp, "%08X", ThunkOffset);
	ListView_SetItemText(hDataView2,iCount,1,stemp);
	sprintf(stemp, "%08X", ThunkValue);
	ListView_SetItemText(hDataView2,iCount,2,stemp)
	if(ApiName!=NULL)
	{
		sprintf(stemp, "%04X", Hint);
	}
	else
	{
		sprintf(stemp, "-", Hint);
	}
	ListView_SetItemText(hDataView2,iCount,3,stemp);
	if(ApiName!=NULL)
	{
		ListView_SetItemText(hDataView2,iCount,4,ApiName);
	}
	else
	{
		sprintf(stemp, "Ordinal: %04X", Ordinal);
		ListView_SetItemText(hDataView2,iCount,4,stemp);
	}
	iCount++;
}

void DataView2_ClearList()
{
	iCount = 0;
	ListView_DeleteAllItems(hDataView2);
}
