/* main.cpp : Defines the entry point for the application.

   This file is part of the "PE Maker".

   Copyright (C) 2005-2006 Ashkbiz Danehkar
   All Rights Reserved.

   "PE Maker" library are free software; you can redistribute them
   and/or modify them under the terms of the GNU General Public License as
   published by the Free Software Foundation.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; see the file COPYRIGHT.TXT.
   If not, write to the Free Software Foundation, Inc.,
   59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

   yodap's Site:
   http://yodap.sourceforge.net

   Ashkbiz Danehkar
   <ashkbiz@yahoo.com>
*/

//#define  WIN32_LEAN_AND_MEAN
#include "stdafx.h"
#include "main.h"
#include <commdlg.h>
#include <shellapi.h>
#include <windowsx.h>
#include "dataview1.h"
#include "dataview2.h"
#include "About.h"

#pragma comment(linker,"/BASE:0x400000 /FILEALIGN:0x200 /MERGE:.rdata=.text /MERGE:.data=.text /SECTION:.text,EWR /IGNORE:4078")
#pragma pack(1)

#ifdef AP_UNIX_STYLE
   #include <unistd.h>
   #define CB_CALLCONV
#else
   #include <io.h>
   #define AP_HAS_CONIO
   #ifdef AP_DLL
      #define CB_CALLCONV __stdcall
   #else
      #define CB_CALLCONV __cdecl
   #endif
#endif

// Global Variables:

HINSTANCE hInst;	// current instance

HDROP	hDrop;
HICON	hIcon;
HWND	hButton;

HWND	hwndMain;		// main application window 
HMENU	hSysMenu;

HACCEL	hAccel;

// Forward declarations of functions included in this code module:
char cFname[256];
char cFnameOpen[256];
char cFnameSave[256];

OPENFILENAME openfn;
OPENFILENAME savefn;
DWORD nFilterIndex=1;
char szCurDir[]=".";
char szFilterOpn[]=TEXT("Executable files (*.exe)\0*.exe\0Dynamic Link Libraries (*.dll)\0*.dll\0OLE-ActiveX Controls (*.ocx)\0*.ocx\0Screen Savers (*.scr)\0*.scr\0All files (*.*)\0*.*\0\0");
char szFilterSave[]=TEXT("All files (*.*)\0*.*\0\0");
char* szAbout = "About...";

ITLibrary 	*itlib;
BOOL		bFileOpen=FALSE;

LRESULT DlgProc(HWND hDlg,UINT uMsg,WPARAM wParam,LPARAM lParam);
BOOL OnInitDialog(HWND hwnd, HWND hwndFocus, LPARAM lParam);
void OnCommand (HWND hwnd, int id, HWND hwndCtl, UINT codeNotify);
void OnSysCommand(HWND hwnd, UINT cmd, int x, int y);
void OnDropFiles(HWND hwnd, HDROP hDrop);
void OnPaint (HWND hwnd);
void OnDestroy (HWND hwnd);
void OnClose(HWND hwnd);
LRESULT OnNotify(HWND hwnd,WPARAM wParam,NMHDR* nmheader);
static int CB_CALLCONV callback1(PCHAR pDllName, 
								 DWORD OriginalFirstThunk,
								 DWORD TimeDateStamp,
								 DWORD ForwarderChain,
								 DWORD Name,
								 DWORD FirstThunk);
static int CB_CALLCONV callback2(DWORD ThunkRVA,
								 DWORD ThunkOffset,
								 DWORD ThunkValue,
								 DWORD Hint,
								 PCHAR ApiName, 
								 DWORD Ordinal);

int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	MSG msg;
	hInst=GetModuleHandle(0);
	DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_MAINDLG),0,(DLGPROC)DlgProc,0);
	ExitProcess(0);
	return (int) msg.wParam;
}

void EnableItems(HWND hDlg)
{
	hButton=GetDlgItem(hDlg,IDC_STATIC1); 
	EnableWindow(hButton,TRUE);
	hButton=GetDlgItem(hDlg,IDC_PASSWORD); 
	EnableWindow(hButton,TRUE);
	hButton=GetDlgItem(hDlg,IDC_STATIC2); 
	EnableWindow(hButton,TRUE);
	hButton=GetDlgItem(hDlg,IDC_ALG_ID); 
	EnableWindow(hButton,TRUE);
	hButton=GetDlgItem(hDlg,IDC_ENCRYPT); 
	EnableWindow(hButton,TRUE);
	hButton=GetDlgItem(hDlg,IDC_DECRYPT); 
	EnableWindow(hButton,TRUE);
}

// internal helpers
// 
static void FrameWindow(HWND hWnd)
{
	if (!IsWindow(hWnd)) return;

	RECT wndRect;
	GetWindowRect(hWnd,&wndRect);
	//   wndRect.NormalizeRect();
	SetRect(&wndRect,0,0,
		wndRect.right - wndRect.left,
		wndRect.bottom - wndRect.top);

	HDC      hDC;
	int      iOldROP;
	HPEN     hPen;
	HPEN     hOldPen;
	HBRUSH   hOldBrush;

	hDC = GetWindowDC(hWnd);
	iOldROP = SetROP2(hDC, R2_XORPEN);
	hPen = CreatePen(PS_SOLID, GetSystemMetrics(SM_CXSIZEFRAME), RGB(255, 255, 255));
	hOldPen = (HPEN)SelectObject(hDC, hPen);
	hOldBrush = (HBRUSH)SelectObject(hDC, GetStockObject(NULL_BRUSH));

	Rectangle(hDC, wndRect.left, wndRect.top, wndRect.right, wndRect.bottom);
   
	SelectObject(hDC, hOldBrush);
	SelectObject(hDC, hOldPen);
	DeleteObject(hPen);
	SetROP2(hDC, iOldROP);
	ReleaseDC(hWnd, hDC);
}

//  FUNCTION: DlgProc(HWND, unsigned, WORD, LONG)
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
LRESULT DlgProc(HWND hDlg,UINT uiMsg,WPARAM wParam,LPARAM lParam)
{
	//UINT wmId, wmEvent;
	switch (uiMsg) 
	{
	HANDLE_MSG(hDlg, WM_INITDIALOG,	OnInitDialog);
	HANDLE_MSG(hDlg, WM_COMMAND,	OnCommand);
	HANDLE_MSG(hDlg, WM_SYSCOMMAND,	OnSysCommand);
	HANDLE_MSG(hDlg, WM_PAINT,		OnPaint);
	HANDLE_MSG(hDlg, WM_DESTROY,	OnDestroy);
	HANDLE_MSG(hDlg, WM_CLOSE,		OnClose);
	HANDLE_MSG(hDlg, WM_DROPFILES,	OnDropFiles);
	HANDLE_MSG(hDlg, WM_NOTIFY,		OnNotify);
	}
	return 0;
}

BOOL OnInitDialog(HWND hwnd, HWND hwndFocus, LPARAM lParam)
{
	hwndMain=hwnd;
	hIcon=LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON));
	SendMessage(hwnd,WM_SETICON,TRUE,(WPARAM)hIcon);
	hAccel=LoadAccelerators(hInst,MAKEINTRESOURCE(IDC_CRYPTAPI));
	DragAcceptFiles(hwnd,TRUE);
	hSysMenu = GetSystemMenu(hwnd,FALSE);
	if (hSysMenu != NULL)
	{
		AppendMenu(hSysMenu,MF_SEPARATOR,0,0);
		AppendMenu(hSysMenu,MF_STRING | MF_ENABLED,
				ID_ABOUT,szAbout);
	}
	itlib=new (ITLibrary);
	DataView1_OnInitDialog(hwnd, hwndFocus, lParam);
	DataView2_OnInitDialog(hwnd, hwndFocus, lParam);
	return FALSE;
}

int CB_CALLCONV callback(unsigned int dwpos)
{
	SendDlgItemMessage(hwndMain,IDC_PROGRESS1,PBM_SETPOS,DWORD(dwpos),0);
	return (1); // continue packing
}

/****************************************************************************
*								OnCommand
*
*  hwnd			Handle of window to which this message applies
*  id			Specifies the identifier of the menu item, 
*				control, or accelerator.
*  hwndCtl		Handle of the control sending the message if the message
*				is from a control, otherwise, this parameter is NULL. 
*  codeNotify	Specifies the notification code if the message is from 
*				a control.
*				This parameter is 1 when the message is from an 
*				accelerator.
*				This parameter is 0 when the message is from a menu.
****************************************************************************/
void OnCommand (HWND hwnd, int id, HWND hwndCtl, UINT codeNotify)
{
	switch (id) 
	{	/* id */
		case IDCLOSE:
			SendMessage(hwnd,WM_CLOSE,NULL,NULL);
			break;
              	                  
		case IDOK:
			EndDialog(hwnd,0);
			break;

		case ID_ABOUT:
			DialogBox(hInst, (LPCTSTR)IDD_ABOUTBOX, hwnd, (DLGPROC)About);
			break;     

		case ID_FILE_OPEN:
			// get a file path
 			cFname[0]=0x00;
			ZeroMemory(&openfn, sizeof(openfn));
			openfn.hwndOwner=GetActiveWindow();
			openfn.lpstrFile=cFname;
			openfn.nMaxFile=sizeof(cFname);
			openfn.lStructSize=sizeof(openfn);
			openfn.lpstrFilter=szFilterOpn; 
			openfn.nFilterIndex=nFilterIndex;
			//openfn.lpstrInitialDir=szCurDir;
			openfn.Flags=OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_LONGNAMES | OFN_HIDEREADONLY;
			if(!GetOpenFileName(&openfn))
			{
				return;
			}
			strcpy(cFnameOpen,cFname);
			SetDlgItemText(hwnd,IDC_FILE_OPEN,cFnameOpen);
			EnableItems(hwnd);
			if(cFnameOpen[0]==0x00) return;
			itlib->OpenFileName(cFnameOpen);
			DataView1_ClearList();
			DataView2_ClearList();
			itlib->GetImportDllName( callback1);
			bFileOpen=TRUE;
			break;
	}/* id */
}

/****************************************************************************
*								OnSysCommand
****************************************************************************/
void OnSysCommand(HWND hwnd,UINT cmd, int x, int y)
{
	switch (cmd) 
	{	/* id */
		case ID_ABOUT:
			DialogBox(hInst, (LPCTSTR)IDD_ABOUTBOX, hwnd, (DLGPROC)About);
			break;     
	}/* id */
}

/****************************************************************************
*								OnPaint
*
*  hwnd            Handle of window to which this message applies
*
*  hdrop           Handle of drop
*
****************************************************************************/
void OnDropFiles(HWND hwnd, HDROP hDrop)
{
	DragQueryFile(hDrop,0,cFnameOpen,sizeof(cFnameOpen));
	DragFinish(hDrop);
	SetDlgItemText(hwnd,IDC_FILE_OPEN,cFnameOpen);
	EnableItems(hwnd);
	if(cFnameOpen[0]!=0x00)
	{
		itlib->OpenFileName(cFnameOpen);
		bFileOpen=TRUE;
	}
}

/****************************************************************************
*								OnPaint
*
*  hwnd            Handle of window to which this message applies
*
*  PURPOSE:        Windows calls this handler when the window needs 
*			       repainting.
****************************************************************************/
void OnPaint (HWND hwnd)
{
    HDC         hdc ;
    PAINTSTRUCT ps ;

	hdc = BeginPaint(hwnd, &ps);
	// TODO: Add any drawing code here...
	EndPaint(hwnd, &ps);
}

/****************************************************************************
*								OnDestroy
*
*  hwnd            Handle of window to which this message applies
*
*  PURPOSE:        Notification that the specified window is being destroyed.
*                  The window is no longer visible to the user.
****************************************************************************/
void OnDestroy (HWND hwnd)
{
	delete itlib;
	PostQuitMessage(0);;
}

/****************************************************************************
*								OnClose
*
*  hwnd            Handle of window to which this message applies
*
*  PURPOSE:        Notification that the specified window is being closed.
*
****************************************************************************/
void OnClose(HWND hwnd)
{
	EndDialog(hwnd,0);
}

LRESULT OnNotify(HWND hwnd,WPARAM wParam,NMHDR* nmheader)
{
	int item;
	if(nmheader->hwndFrom==hDataView1)
	{
		switch(nmheader->code)
		{
		case NM_DBLCLK :
			break;

		case NM_CLICK:
			item= ListView_GetHotItem(hDataView1);
			if(bFileOpen==TRUE)
			{
				DataView2_ClearList();
				itlib->GetImportProcName(item, callback2);
			}
			break;

        case TVN_BEGINDRAG:
            break;
		
		case TVN_SELCHANGED:
			break;

		}
	}
	return 0;
}

static int CB_CALLCONV callback1(PCHAR pDllName, 
								 DWORD OriginalFirstThunk,
								 DWORD TimeDateStamp,
								 DWORD ForwarderChain,
								 DWORD Name,
								 DWORD FirstThunk)
{
	DataView1_Insert(pDllName, 
					OriginalFirstThunk,
					TimeDateStamp,
					ForwarderChain,
					Name,
					FirstThunk);
	return 1; // continue...
}

static int CB_CALLCONV callback2(DWORD ThunkRVA,
								 DWORD ThunkOffset,
								 DWORD ThunkValue,
								 DWORD Hint,
								 PCHAR ApiName, 
								 DWORD Ordinal)
{
	DataView2_Insert(ThunkRVA,
					ThunkOffset,
					ThunkValue,
					Hint,
					ApiName,
					Ordinal);
	return 1; // continue...
}