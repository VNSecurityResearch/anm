/* dataview1.cpp --

   This file is part of the "PE Maker".

   Copyright (C) 2005-2006 Ashkbiz Danehkar
   All Rights Reserved.

   "PE Maker" library are free software; you can redistribute them
   and/or modify them under the terms of the GNU General Public License as
   published by the Free Software Foundation.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; see the file COPYRIGHT.TXT.
   If not, write to the Free Software Foundation, Inc.,
   59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

   Ashkbiz Danehkar
   <ashkbiz@yahoo.com>
*/
#include "stdafx.h"
#include <windowsx.h>
#include <commctrl.h>
#include <stdio.h>
#include "dataview1.h"
#include "main.h"

DATAVIEW		*szDataView1;
int				iDataView1;
HWND			hDataView1;
static DWORD	dwStyle;
static DWORD	dwExtendedStyle;

static int iCount;

//bFileOpen
BOOL DataView1_OnInitDialog(HWND hwnd, HWND hwndFocus, LPARAM lParam);
void DataView1_OnCommand (HWND hwnd, int id, HWND hwndCtl, UINT codeNotify);
void DataView1_Insert(PCHAR pDllName, 
					DWORD OriginalFirstThunk,
					DWORD TimeDateStamp,
					DWORD ForwarderChain,
					DWORD Name,
					DWORD FirstThunk);
void DataView1_ClearList();

#define C_COLUMNS 6
// InitListViewColumns - adds columns to a list-view
// control. 
// Returns TRUE if successful, or FALSE otherwise. 
// hWndListView - handle to the list-view control. 
static int iWidth[C_COLUMNS ]={100,100,100,100,100, 100};
BOOL DataView1_InitListViewColumns(HWND hWndListView) 
{ 
    char szText[256];     // temporary buffer 
    LVCOLUMN lvc; 
    int iCol; 
	// Initialize the LVCOLUMN structure.
	// The mask specifies that the format, width, text, and
	// subitem members of the structure are valid. 
	lvc.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM; 	  
	// Add the columns. 
	for (iCol = 0; iCol < C_COLUMNS; iCol++) 
	{
		lvc.iSubItem = iCol;
		lvc.pszText = szText;
		lvc.cx = iWidth[iCol];     // width of column in pixels
		lvc.fmt = LVCFMT_LEFT;  // left-aligned column
		LoadString(hInst, IDS_D1_FIRSTCOLUMN + iCol, 
			szText, sizeof(szText)/sizeof(szText[0]));
		if (ListView_InsertColumn(hWndListView, iCol,&lvc) == -1) 
			return FALSE; 
	}
	return TRUE; 
} 

// This code snippet adds three items, each with three
// subitems, to a list-view control. 
// hWndListView - handle to the list-view control.
// The following application-specific structure, 
// PETINFO, is used in the snippet.

//static DATAVIEW DataView;

BOOL DataView1_OnInitDialog(HWND hwnd, HWND hwndFocus, LPARAM lParam)
{
	//SECINFO SectionInfo;
	hDataView1=GetDlgItem(hwnd,IDC_DLLNAMES);
	dwStyle = GetWindowLong(hDataView1, GWL_STYLE);
	dwStyle|= LVS_REPORT | LVS_SINGLESEL;
	dwStyle&=~LVS_NOSCROLL;
	SetWindowLong(hDataView1, GWL_STYLE, dwStyle);
	DataView1_InitListViewColumns(hDataView1);
	iCount = 0;
	return FALSE;
}

void DataView1_Insert(PCHAR pDllName, 
					DWORD OriginalFirstThunk,
					DWORD TimeDateStamp,
					DWORD ForwarderChain,
					DWORD Name,
					DWORD FirstThunk)
{
	CHAR stemp[127];
	LVITEM lvI;
	// Some code to create the list-view control.
	// Initialize LVITEM members that are common to all
	lvI.mask =  LVIF_TEXT | LVIF_STATE ; 
	lvI.state = 0; 
	lvI.stateMask = 0; 
	// Initialize LVITEM members that are different for each item. 
	lvI.iItem = iCount;
	lvI.iSubItem = 0;
	lvI.pszText = (LPSTR)pDllName;
	if(ListView_InsertItem(hDataView1, &lvI) == -1) return;
	sprintf(stemp, "%08X", OriginalFirstThunk);
	ListView_SetItemText(hDataView1,iCount,1,stemp);
	sprintf(stemp, "%08X", TimeDateStamp);
	ListView_SetItemText(hDataView1,iCount,2,stemp)
	sprintf(stemp, "%08X", ForwarderChain);
	ListView_SetItemText(hDataView1,iCount,3,stemp);
	sprintf(stemp, "%08X", Name);
	ListView_SetItemText(hDataView1,iCount,4,stemp)
	sprintf(stemp, "%08X", FirstThunk);
	ListView_SetItemText(hDataView1,iCount,5,stemp)
	iCount++;
}

void DataView1_ClearList()
{
	iCount = 0;
	ListView_DeleteAllItems(hDataView1);
}
