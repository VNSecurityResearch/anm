/* dataview2.h --

   This file is part of the "PE Maker".

   Copyright (C) 2005-2006 Ashkbiz Danehkar
   All Rights Reserved.

   "PE Maker" library are free software; you can redistribute them
   and/or modify them under the terms of the GNU General Public License as
   published by the Free Software Foundation.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; see the file COPYRIGHT.TXT.
   If not, write to the Free Software Foundation, Inc.,
   59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

   Ashkbiz Danehkar
   <ashkbiz@yahoo.com>
*/
#pragma once

#include "resource.h"

typedef struct tagDATAVIEW2
{
	char szOffset[10];
	char szData[32];
	char szDescription[64];
	char szValue[64];
}DATAVIEW2;

extern DATAVIEW2 *szDataView2;
extern int		iDataView2;
extern HWND		hDataView2;

extern BOOL DataView2_OnInitDialog(HWND hwnd, HWND hwndFocus, LPARAM lParam);
extern void DataView2_OnCommand (HWND hwnd, int id, HWND hwndCtl, UINT codeNotify);
extern void DataView2_Insert(DWORD ThunkRVA,
							DWORD ThunkOffset,
							DWORD ThunkValue,
							DWORD Hint,
							PCHAR ApiName, 
							DWORD Ordinal);
extern void DataView2_ClearList();
