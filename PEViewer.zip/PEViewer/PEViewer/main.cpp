#include<tchar.h>
#include<Windows.h>
#include<wincrypt.h>
#include<Commdlg.h>
#include<commctrl.h>

// Khai bao cac ham
INT_PTR CALLBACK DialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
void DisplayMessage(HWND hwnd, char msg[]);
void DisplayTreeView(HWND hwnd);
void Finish();

// Ket noi ID cua cac control
#include "resource.h"

HINSTANCE hIns;
OPENFILENAMEA ofn;
HANDLE hFile = NULL;
HANDLE hMapping = NULL;
LPVOID pMapping;
PIMAGE_DOS_HEADER dosHeader;
PIMAGE_NT_HEADERS ntHeader;
char filename[80] = "";			// Luu ten file voi full path
char AppName[] = "PEViewer";	// Dung cho MessageBox

TV_ITEM tvItem;
TV_INSERTSTRUCT tvInsert;
HTREEITEM Selected;
HTREEITEM Parent;
HTREEITEM Before;
HTREEITEM Root;

LV_COLUMN lvCol;
LV_ITEM lvItem;
LV_DISPINFO lvD;
int iSelect = 0;
int index = 0;
int flag = 0;


bool isSelected = false;

HIMAGELIST hImageList;
HBITMAP hBitMap;

HWND hStaticTextPath;
HWND hTreeView;
HWND hListView;

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
	// Khoi tao cac gia tri cua OPENFILENAME
	// https://msdn.microsoft.com/en-us/library/windows/desktop/ms646839(v=vs.85).aspx
	ZeroMemory(&ofn, sizeof(ofn));
	ofn.lStructSize = sizeof(ofn);
	ofn.hwndOwner = NULL;
	ofn.hInstance = hInstance;
	ofn.lpstrFile = filename;								// Ten file
	ofn.lpstrFilter = "Exe\0*.EXE*\0Text\0*.TXT\0";			// Chuoi loc file
	ofn.nMaxFile = sizeof(filename);						// Kich thuoc ten file

	hIns = hInstance;

	// Khoi tao DialogBoxParam
	DialogBoxParam(
		hInstance,
		MAKEINTRESOURCE(MY_DIALOG),
		NULL,
		DialogProc,
		NULL
		);
	return 0;
}

// Callback that handle message loop
INT_PTR CALLBACK DialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
		case WM_INITDIALOG:
			InitCommonControls();
			hTreeView = GetDlgItem(hwndDlg, TREE_VIEW);
			hImageList = ImageList_Create(16, 16, ILC_COLOR16, 2, 10);
			hBitMap = LoadBitmap(hIns, MAKEINTRESOURCE(ICON_FILE));
			ImageList_Add(hImageList, hBitMap, NULL);
			DeleteObject(hBitMap);

			SendDlgItemMessage(hwndDlg, TREE_VIEW, TVM_SETIMAGELIST, 0, (LPARAM) hImageList);
			break;
		case WM_LBUTTONDOWN:
			ReleaseCapture();
			SendMessage(hwndDlg, WM_NCLBUTTONDOWN, HTCAPTION, 0);
			break;
		case WM_NOTIFY: 
			{
				case TREE_VIEW:
					if (((LPNMHDR) lParam)->code == NM_DBLCLK) // if code == NM_CLICK - Single click on an item
					{
						char Text[255] = "";
						memset(&tvItem, 0, sizeof(tvItem));

						Selected = (HTREEITEM) SendDlgItemMessage(hwndDlg, TREE_VIEW, TVM_GETNEXTITEM, TVGN_CARET, (LPARAM) Selected);

						if (Selected == NULL) {
							DisplayMessage(hwndDlg, "No Items in TreeView");
							break;
						}
						TreeView_EnsureVisible(hwndDlg, Selected);
						SendDlgItemMessage(hwndDlg, TREE_VIEW, TVM_SELECTITEM, TVGN_CARET, (LPARAM) Selected);
						isSelected = true;
						tvItem.mask = TVIF_TEXT;
						tvItem.pszText = (LPWSTR) Text;
						tvItem.cchTextMax = 256;
						tvItem.hItem = Selected;
					}
			}
			break;
		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
				case BTN_OPENFILE:
					ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_LONGNAMES | OFN_EXPLORER | OFN_HIDEREADONLY;
					if (GetOpenFileNameA(&ofn)) {
						hStaticTextPath = GetDlgItem(hwndDlg, STATIC_PATH);
						SetWindowTextA(hStaticTextPath, ofn.lpstrFile);

						hFile = CreateFileA(ofn.lpstrFile, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, NULL);
						if (hFile != INVALID_HANDLE_VALUE) {
							hMapping = CreateFileMapping(hFile, NULL, PAGE_READONLY, 0, 0, 0);
							pMapping = MapViewOfFile(hMapping, FILE_MAP_READ, 0, 0, 0);

							tvInsert.hParent = NULL;
							tvInsert.hInsertAfter = TVI_ROOT;
							tvInsert.item.mask = TVIF_TEXT | TVIF_IMAGE | TVIF_SELECTEDIMAGE;
							tvInsert.item.pszText = _TEXT("Header");
							tvInsert.item.iImage = 0;
							tvInsert.item.iSelectedImage = 1;
							Parent = (HTREEITEM)SendDlgItemMessage(hwndDlg, TREE_VIEW, TVM_INSERTITEM, 0, (LPARAM)&tvInsert);

							dosHeader = (PIMAGE_DOS_HEADER) pMapping;
							if (dosHeader->e_magic == IMAGE_DOS_SIGNATURE) {
								Root = Parent;
								Before = Parent;                   // handle of the before root
								tvInsert.hParent = Parent;         // handle of the above data
								tvInsert.hInsertAfter = TVI_LAST;  // below parent
								tvInsert.item.pszText = _TEXT("Dos Header");
								Parent = (HTREEITEM)SendDlgItemMessage(hwndDlg, TREE_VIEW, TVM_INSERTITEM, 0, (LPARAM)&tvInsert);

								ntHeader = (PIMAGE_NT_HEADERS)((DWORD)(dosHeader) + (dosHeader->e_lfanew));
								if (ntHeader->Signature == IMAGE_NT_SIGNATURE) {
									tvInsert.hParent = Before;         // handle of the above data
									tvInsert.hInsertAfter = TVI_LAST;  // below parent
									tvInsert.item.pszText = _TEXT("NT Header");
									Parent = (HTREEITEM)SendDlgItemMessage(hwndDlg, TREE_VIEW, TVM_INSERTITEM, 0, (LPARAM)&tvInsert);
								
									tvInsert.hParent = NULL;         // handle of the above data
									tvInsert.hInsertAfter = TVI_LAST;  // below parent
									tvInsert.item.pszText = _TEXT("Export");
									Parent = (HTREEITEM)SendDlgItemMessage(hwndDlg, TREE_VIEW, TVM_INSERTITEM, 0, (LPARAM)&tvInsert);
								
									tvInsert.hParent = Before;         // handle of the above data
									tvInsert.hInsertAfter = TVI_LAST;  // below parent
									tvInsert.item.pszText = _TEXT("Import");
									Parent = (HTREEITEM)SendDlgItemMessage(hwndDlg, TREE_VIEW, TVM_INSERTITEM, 0, (LPARAM)&tvInsert);
								} else {
									DisplayMessage(hwndDlg, "This is not a valid PE file!");
									Finish();
								}
							} else {
								DisplayMessage(hwndDlg, "This is not a valid PE file!");
								Finish();
							}
						} else {
							DisplayMessage(hwndDlg, "Can't open this file!");
							Finish();
						}
					}
					break;
				case BTN_CLOSEFILE:
					Finish();
					EndDialog(hwndDlg, 0);
					break;
				default:
					Finish();
			}
			break;
		case WM_CLOSE:
			Finish();
			EndDialog(hwndDlg, 0);
			break;
		default:
			CloseHandle(hFile);
	}

	return 0;
}

void Finish() {
	UnmapViewOfFile(pMapping);
	CloseHandle(hFile);
}

// Ham hien thi cac message
void DisplayMessage(HWND hwnd, char msg[])
{
	MessageBoxA(hwnd, msg, AppName, MB_OK);
}

// Ham hien thi Tree View
void DisplayTreeView(HWND hwnd)
{
	

	
	
	
	tvInsert.hParent = Parent;
	tvInsert.hInsertAfter = TVI_LAST;
	tvInsert.item.pszText = _TEXT("Double Click Me!");
	tvInsert.item.mask = TVIF_TEXT;

	
	
}