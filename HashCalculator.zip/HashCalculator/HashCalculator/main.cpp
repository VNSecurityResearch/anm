#include<tchar.h>
#include<Windows.h>
#include<wincrypt.h>
#include<Commdlg.h>

#define BUFSIZE 1024
#define MD5LEN 16	

INT_PTR CALLBACK DialogProc(_In_ HWND   hwndDlg, _In_ UINT   uMsg, _In_ WPARAM wParam, _In_ LPARAM lParam);

#include "resource.h"

OPENFILENAME ofn;
HANDLE hFile;
HCRYPTPROV hProv;
char buffer[BUFSIZE];

int WINAPI WinMain(_In_ HINSTANCE hInstance, _In_opt_ HINSTANCE hPrevInstance, _In_ LPSTR lpCmdLine, _In_ int nShowCmd) 
{
	// Open file
	ZeroMemory(&ofn, sizeof(ofn));
	ofn.lStructSize = sizeof(ofn);
	ofn.hwndOwner = NULL;
	ofn.hInstance = hInstance;
	ofn.lpstrFile = buffer;
	ofn.lpstrFilter = _TEXT("All\0*.*\0Text\0*.TXT\0");
	ofn.nMaxFile = sizeof(buffer);

	DialogBoxParam(
		hInstance,
		MAKEINTRESOURCE(IDD_DIALOG1),
		NULL,
		DialogProc,
		NULL
	);
	return 0;
}

INT_PTR CALLBACK DialogProc(_In_ HWND hwndDlg, _In_ UINT uMsg, _In_ WPARAM wParam, _In_ LPARAM lParam)
{
	switch (uMsg)
	{
		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
				case BTN_OPENFILE:
					ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_LONGNAMES | OFN_EXPLORER | OFN_HIDEREADONLY;
					if (!GetOpenFileName(&ofn)) {
						hFile = CreateFile(buffer, GENERIC_READ|GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_ARCHIVE, NULL);
					}
					break;
				default:
					return FALSE; 
			}
			break; 
		case WM_CLOSE: 
			CloseHandle(hFile);
			EndDialog(hwndDlg, 0);
			break;

		default:
			return FALSE; 
	}

	return TRUE; 
}